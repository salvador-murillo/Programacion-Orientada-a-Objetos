package mx.udg.cucea.datos;


import java.io.FileWriter;
import java.io.IOException;
import mx.udg.cucea.vehiculos.Automovil;
import mx.udg.cucea.vehiculos.Transporte;
import mx.udg.cucea.vehiculos.TrenLigero;

public class EscritorArchivoTransporte extends FileWriter{
    private Transporte transporte;
    public EscritorArchivoTransporte(Transporte t) throws IOException {
        super(t.getPlacas());
        this.transporte = t;
    }
    
    public void escribirArchivo() throws IOException{
        append(transporte.getPropietario());
        append(System.lineSeparator());
        append(transporte.getMarca());
        append(System.lineSeparator());  
        append(transporte.getModelo());
        append(System.lineSeparator());   
        append(String.valueOf(transporte.getAño()));
        append(System.lineSeparator());
        append(String.valueOf(transporte.getNumeroDeSerie()));
        append(System.lineSeparator());  
        append(String.valueOf(transporte.getNumeroDePuertas()));
        append(System.lineSeparator());  
        append(String.valueOf(transporte.getNumeroDeMotor()));
        append(System.lineSeparator()); 
        append(transporte.getTipoDeCombustible());  
        if(transporte instanceof Automovil){
            Automovil a = (Automovil) transporte;
            append(System.lineSeparator());
            append(a.getTransmision()); 
            append(System.lineSeparator());
            append(String.valueOf(a.getNumeroDeCilindros()));
            append(System.lineSeparator());
            append(a.getColor().toString());
        }
        else if (transporte instanceof TrenLigero){
            TrenLigero tren = (TrenLigero) transporte;
            append(System.lineSeparator());
            append(String.valueOf(tren.getNumeroDeTren()));
            append(System.lineSeparator());
            append(tren.getSistemaDeManejo());            
            append(System.lineSeparator());
            append(String.valueOf(tren.getNumeroDeVagones()));              
        }
    }
}